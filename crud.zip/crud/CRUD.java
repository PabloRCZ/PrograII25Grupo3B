/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package gt.edu.umg.crud;

/**
 *
 * @author caste
 */
public class CRUD {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
